async function loginUser() {
    const phone = document.getElementById('loginPhone').value;
    const pass = document.getElementById('loginPass').value;

    if (!phone || !pass) {
        alert("Please enter both phone and password");
        return;
    }

    try {
        const response = await fetch('http://localhost:3000/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ PhoneNumber: phone, Password: pass })
        });

        const result = await response.json();

        if (response.ok) {
            // Store user info for the dashboard
            localStorage.setItem('userName', result.user.FullName);
            localStorage.setItem('userRole', result.user.UserRole);
            
            alert("Login Successful! Welcome " + result.user.FullName);
            window.location.href = 'dashboard.html'; // Redirect to dashboard
        } else {
            alert(result.message);
        }
    } catch (error) {
        alert("Server is not responding. (Wait for MySQL to finish installing!)");
    }
}