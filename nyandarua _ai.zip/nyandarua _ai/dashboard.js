// Display the logged-in user's name
document.getElementById('displayUser').innerText = localStorage.getItem('userName') || "Guest";

async function askAI() {
    const inputField = document.getElementById('userInput');
    const chatWindow = document.getElementById('chatWindow');
    const question = inputField.value;

    if (!question) return;

    // 1. Show user message in chat
    chatWindow.innerHTML += `<div class="user-msg"><b>You:</b> ${question}</div>`;
    inputField.value = ""; // Clear input

    try {
        const response = await fetch('http://localhost:3000/ask-ai', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: question })
        });

        const data = await response.json();
        
        // 2. Show AI response
        chatWindow.innerHTML += `<div class="ai-msg"><b>AI Assistant:</b> ${data.answer}</div>`;
        
        // Scroll to bottom
        chatWindow.scrollTop = chatWindow.scrollHeight;

    } catch (error) {
        chatWindow.innerHTML += `<div class="ai-msg" style="color:red;">Error: Is the server running?</div>`;
    }
}

function logout() {
    localStorage.clear();
    window.location.href = 'login.html';
}

async function payForVet() {
    const phone = prompt("Enter M-Pesa Phone Number (254...):");
    
    if (!phone) return;

    try {
        const response = await fetch('http://localhost:3000/pay-mpesa', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone: phone, amount: 500 })
        });

        const data = await response.json();
        if(data.success) {
            alert(data.message);
        }
    } catch (error) {
        alert("Payment system offline. Ensure server is running!");
    }
}