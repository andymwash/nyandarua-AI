CREATE DATABASE IF NOT EXISTS nyandarua_ai;
USE nyandarua_ai;

-- Table for Farmers and Vets
CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    FullName VARCHAR(100),
    PhoneNumber VARCHAR(15),
    UserRole ENUM('Farmer', 'Vet', 'Admin'),
    PasswordHash VARCHAR(255)
);