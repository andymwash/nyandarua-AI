const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const axios = require('axios');
const { GoogleGenerativeAI } = require("@google/generative-ai");

const app = express();
app.use(cors());
app.use(express.json());

// 1. Connect to MySQL
const db = mysql.createConnection({
    host: '127.0.0.1',
    port: 3307,
    user: 'root',
    password: '', 
    database: 'nyandarua_ai',
    connectTimeout: 10000
});

db.connect((err) => {
    if (err) {
        console.error('Database connection failed: ' + err.stack);
        return;
    }
    console.log('✅ Connected to Nyandarua Database.');
});

// 2. Gemini AI Setup
// REPLACE "PASTE_YOUR_GEMINI_API_KEY_HERE" with your actual key!
const genAI = new GoogleGenerativeAI("AIzaSyBnkbKJYam4jVkzFBITjm5qXYgXghDex8o");
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// --- ROUTES ---

app.get('/', (req, res) => {
    res.send("Nyandarua AI Server is Running!");
});

app.post('/register', (req, res) => {
    const { FullName, PhoneNumber, UserRole, PasswordHash } = req.body;
    const sql = "INSERT INTO Users (FullName, PhoneNumber, UserRole, PasswordHash) VALUES (?, ?, ?, ?)";
    db.query(sql, [FullName, PhoneNumber, UserRole, PasswordHash], (err, result) => {
        if (err) return res.status(500).json({ message: "Error: " + err.message });
        res.status(200).json({ message: "User registered successfully!" });
    });
});

app.post('/login', (req, res) => {
    const { PhoneNumber, PasswordHash } = req.body;
    const sql = "SELECT * FROM Users WHERE PhoneNumber = ? AND PasswordHash = ?";
    db.query(sql, [PhoneNumber, PasswordHash], (err, results) => {
        if (err) return res.status(500).json({ message: "Server error" });
        if (results.length > 0) {
            res.status(200).json({ message: "Login successful!", user: results[0] });
        } else {
            res.status(401).json({ message: "Invalid Phone Number or Password" });
        }
    });
});

app.post('/ask-ai', async (req, res) => {
    try {
        const { prompt } = req.body;
        console.log("Farmer asked:", prompt); // Logs to your terminal

        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text(); // Extracts the actual message

        console.log("Gemini replied:", text); // Check your terminal for this!
        res.json({ answer: text }); // Sends "answer" to your browser
    } catch (error) {
        console.error("Gemini Error:", error);
        res.status(500).json({ answer: "I'm having trouble connecting to my brain. Check your API key!" });
    }
});

// --- M-PESA SECTION ---
const consumerKey = "YOUR_CONSUMER_KEY";
const consumerSecret = "YOUR_CONSUMER_SECRET";
const shortCode = "174379"; 
const passkey = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919";

async function getMpesaToken() {
    const auth = Buffer.from(`${consumerKey}:${consumerSecret}`).toString('base64');
    try {
        const response = await axios.get(
            "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials",
            { headers: { Authorization: `Basic ${auth}` } }
        );
        return response.data.access_token;
    } catch (error) {
        console.error("Token Error:", error.response ? error.response.data : error.message);
    }
}

app.post('/stk-push', async (req, res) => {
    const { phone, amount } = req.body;
    const token = await getMpesaToken();
    if (!token) return res.status(500).json({ message: "Failed to get M-Pesa token" });

    const timestamp = new Date().toISOString().replace(/[-:T.Z]/g, "").slice(0, 14);
    const password = Buffer.from(shortCode + passkey + timestamp).toString('base64');

    const stkData = {
        BusinessShortCode: shortCode,
        Password: password,
        Timestamp: timestamp,
        TransactionType: "CustomerPayBillOnline",
        Amount: amount,
        PartyA: phone,
        PartyB: shortCode,
        PhoneNumber: phone,
        CallBackURL: "https://yourdomain.com/callback",
        AccountReference: "NyandaruaAI",
        TransactionDesc: "Farming Services"
    };

    try {
        await axios.post(
           "https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest",
            stkData,
            { headers: { Authorization: `Bearer ${token}` } }
        );
        res.json({ success: true, message: "STK Push sent successfully!" });
    } catch (error) {
        console.error("STK Push Error:", error.response ? error.response.data : error.message);
        res.status(500).json({ success: false, message: "M-Pesa request failed." });
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`🚀 Server is live on http://localhost:${PORT}`);
});