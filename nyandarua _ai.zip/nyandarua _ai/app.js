// 1. Check if user is logged in when page loads
document.addEventListener('DOMContentLoaded', () => {
    const userData = JSON.parse(localStorage.getItem('currentUser'));
    if (userData) {
        // Update the dashboard with the farmer's name
        const welcomeMsg = document.getElementById('welcomeMessage');
        if (welcomeMsg) welcomeMsg.innerText = `Welcome, ${userData.FullName}`;
    } else {
        console.log("No user session found.");
    }
});

// 2. The M-Pesa Payment Function
async function payWithMpesa() {
    const userData = JSON.parse(localStorage.getItem('currentUser'));
    
    if (!userData || !userData.PhoneNumber) {
        alert("Session error. Please log in again.");
        return;
    }

    let phone = userData.PhoneNumber;
    // Format phone to 254 format
    if (phone.startsWith('0')) {
        phone = '254' + phone.substring(1);
    }

    const amount = prompt("Enter amount to pay (KES):", "1");
    if (!amount) return;

    try {
        const response = await fetch('http://localhost:3000/stk-push', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone: phone, amount: amount })
        });

        const result = await response.json();
        alert(result.message);
    } catch (error) {
        console.error("M-Pesa Error:", error);
        alert("Failed to connect to the server.");
    }
}

async function askAI() {
    const input = document.getElementById('chatInput');
    const responseField = document.getElementById('chatResponse');
    const question = input.value;
    const chatHistory = document.getElementById('chatHistory');

// Inside your askAI function after getting data:
const userMsg = `<p><strong>You:</strong> ${question}</p>`;
const aiMsg = `<p style="color: green;"><strong>Nyandarua AI:</strong> ${data.answer}</p>`;

chatHistory.innerHTML += userMsg + aiMsg;
chatHistory.scrollTop = chatHistory.scrollHeight; // Auto-scroll to bottom

    if (!question) return;

    responseField.innerText = "Thinking..."; // Show status
    responseField.style.color = "blue";

    try {
        const response = await fetch('http://localhost:3000/ask-ai', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: question })
        });

        const data = await response.json();
        
        // Log the whole data object to see what's inside (Check F12 console)
        console.log("Server sent back:", data);

        if (data && data.answer) {
            responseField.innerText = data.answer;
            responseField.style.color = "green";
        } else {
            responseField.innerText = "Received empty response from server.";
            responseField.style.color = "orange";
        }
    } catch (error) {
        console.error("Connection error:", error);
        responseField.innerText = "Cannot reach server. Is node server.js running?";
        responseField.style.color = "red";
    }
}